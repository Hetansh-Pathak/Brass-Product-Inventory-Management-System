<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "brass";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['productName'])) {
    $productName = $_POST['productName'];

    // Prepare and bind to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM available_products WHERE productName = ?");
    $stmt->bind_param("s", $productName);

    if ($stmt->execute()) {
      echo "Success";
    } else {
      echo "Error deleting record: " . $stmt->error;
    }

    $stmt->close();
  } else {
    echo "Product name not provided.";
  }
}

$conn->close();
?>
